	// POSTAVI DIV
	// VALIDACIJA
	// DODAJ PORUKU
	// ILI OCISTI GRESKU
function VIme(txt) {
	if (txt==document.getElementById("studentIme")) {
		Poruke.postaviIdDiva("podnozje1");	
	}
	else {
		Poruke.postaviIdDiva("podnozje2");
	}
	if (Validacija.validirajImeiPrezime(txt.value)==false) {
		if (txt==document.getElementById("studentIme")) {
			Poruke.porukeLista.push(0);
		}
		else {
			Poruke.porukeLista.push(1);
		}
		Poruke.dodajPoruku(9);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(9);
	}
}
function VIndex(txt) {
	Poruke.postaviIdDiva("podnozje1");
	if (Validacija.validirajIndex(txt)==false) {
		Poruke.dodajPoruku(1);
		Poruke.porukeLista.push(0);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(1);
	}
}
function VGrupa(txt) {
	Poruke.postaviIdDiva("podnozje1");
	if (Validacija.validirajGrupu(txt)==false) {
		Poruke.dodajPoruku(2);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(2);
	}
}
function VPassword(txt) {
	if (txt==document.getElementById("novi_passwordS")) {
		Poruke.postaviIdDiva("podnozje1");
	}
	else Poruke.postaviIdDiva("podnozje2");
	if (Validacija.validirajPassword(txt.value)==false) {
		if (txt==document.getElementById("novi_passwordS")) {
			Poruke.porukeLista.push(0);
		}
		else Poruke.porukeLista.push(1);
		Poruke.dodajPoruku(4);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(4);
	}
}
function VPotvrda(txt) {
	if (txt==document.getElementById("potvrda_passwordaS")) {
		Poruke.postaviIdDiva("podnozje1");
		var pw= document.getElementById("novi_passwordS").value;
		if (Validacija.validirajPassword(pw)) {
			if (Validacija.validirajPotvrdu(pw, txt.value)==false) {
				Poruke.dodajPoruku(5);
				Poruke.porukeLista.push(0);
				Poruke.ispisiGreske();
			}
			else {
				Poruke.ocistiGresku(5);
			}
		}
	}
	else {
		Poruke.postaviIdDiva("podnozje2");
		var pass= document.getElementById("novi_passwordN").value;
		if (Validacija.validirajPassword(pass)) {
			if (Validacija.validirajPotvrdu(pass, txt.value)==false) {
				Poruke.dodajPoruku(5);
				Poruke.porukeLista.push(1);
				Poruke.ispisiGreske();
			}
			else {
				Poruke.ocistiGresku(5);
			}
		}
	}
}
function VBBURL(txt) {
	Poruke.postaviIdDiva("podnozje1");
	if (Validacija.validirajBitbucketURL(txt)==false) {
		Poruke.dodajPoruku(6);
		Poruke.porukeLista.push(0);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(6);
	}
}
function VBBSSH(txt) {
	Poruke.postaviIdDiva("podnozje1");
	if (Validacija.validirajBitbucketSSH(txt)==false) {
		Poruke.porukeLista.push(0);
		Poruke.dodajPoruku(7);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(7);
	}
}
function VNaziv(txt) {
	Poruke.postaviIdDiva("podnozje1");
	if (Validacija.validirajNazivRepozitorija(txt)==false) {
		Poruke.porukeLista.push(0);
		Poruke.dodajPoruku(8);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(8);
	}
}
function VGodina(txt) {
	if (txt==document.getElementById("akGodinaS")) {
		Poruke.postaviIdDiva("podnozje1");
	}
	else {
		Poruke.postaviIdDiva("podnozje2");
	}
	if (Validacija.validirajAkGod(txt.value)==false) {
		if (txt==document.getElementById("akGodinaS")) {
			Poruke.porukeLista.push(0);
		}
		else {
			Poruke.porukeLista.push(1);
		}
		Poruke.dodajPoruku(3);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(3);
	}
}
function VMail(txt) {
	Poruke.postaviIdDiva("podnozje2");
	if (Validacija.validirajFakultetski(txt)==false) {
		Poruke.porukeLista.push(1);
		Poruke.dodajPoruku(0);
		Poruke.ispisiGreske();
	}
	else {
		Poruke.ocistiGresku(0);
	}
}