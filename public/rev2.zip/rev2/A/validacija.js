var Validacija=(function(){
var maxGrupa=7;
var trenutniSemestar=0;
var validirajFakultetski = function(email) {
	var re= /^[-a-z0-9~!.$%^&*_=+}{\'?]+\@+(etf)+\.+(unsa)+\.+(ba)$/g;
	if (re.exec(email)) return true;
	return false;
}
var validirajIndex = function(index) {
	var re= /^[1][0-9]{4}$/g;
	if (re.exec(index)) return true;
	return false;
}
var validirajGrupu = function(grupa) {

	if (parseInt(grupa)>0 && parseInt(grupa)<maxGrupa) return true;
	return false;
}
var validirajAkGod = function(godina) {
	var re = /^(20[0-9]{2})\/(20[0-9]{2})$/g;
	if (re.exec(godina)==false) return false;
	var g = godina.match(/20\d\d/g);
	var g1 = parseInt(g[0]);
	var g2= parseInt(g[1]);
	if (g2-g1!=1) return false;
	if (trenutniSemestar==0)
	{ 
	 return (g1== new Date().getFullYear());
	}
	else {
		return (g2== new Date().getFullYear());
	}
}
var validirajPassword = function(pw) {
	var re = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d).{7,20}$/g;
	if (re.exec(pw)) return true;
	return false;
}
var validirajPotvrdu = function(p1, p2) {
	if (validirajPassword(p1)==true && validirajPassword(p2)==true) {
		if (p1==p2) return true;
	}
	return false;
}
var validirajBitbucketURL = function(url) {
	var re = /(https\:\/\/)(.*[A-Za-z])(\@bitbucket\.org\/)(.*[A-Za-z])(\/(wtProjekat|wtprojekat)+[1][0-9]{4}\.git)/g;
	if (re.exec(url)) return true;
	return false;
}
var validirajBitbucketSSH = function(ssh) {
	var re = /(git\@bitbucket\.org\:)(.*[A-Za-z])(\/(wtProjekat|wtprojekat)+[1][0-9]{4}\.git)/g;
	return true;
}
var validirajNazivRepozitorija = function(re, naziv) {
	if (re!=null && re.exec(naziv)) return true;
	if (re==null) re=/^(wtProjekat|wtprojekat)+[1][0-9]{4}$/g;
	if (re.exec(naziv)) return true;
	return false;
}
var validirajImeiPrezime = function(ime) {
	re = /^[A-ZČĆŠĐŽ][a-zčćđšž\'\-]{2,11}(\s+[A-ZČĆŠĐŽ]([a-zčćđšž\'\-])*|\s{0})$/g;
	if (re.exec(ime)) return true;
	return false;
}
var postaviMaxGrupa=function(broj) {
	maxGrupa=broj;
}
var postaviTrenSemestar=function(broj) {
	trenutniSemestar=broj;
}
return{
validirajFakultetski : validirajFakultetski,
validirajIndex: validirajIndex,
validirajGrupu: validirajGrupu,
validirajAkGod: validirajAkGod,
validirajPassword: validirajPassword,
validirajPotvrdu: validirajPotvrdu,
validirajBitbucketURL: validirajBitbucketURL,
validirajBitbucketSSH: validirajBitbucketSSH,
validirajNazivRepozitorija: validirajNazivRepozitorija,
validirajImeiPrezime: validirajImeiPrezime,
postaviMaxGrupa: postaviMaxGrupa,
postaviTrenSemestar: postaviTrenSemestar
}
}());

