function like(i) {
	var index=i.rowIndex;
	if (index==1) return false;
	var red = document.getElementsByClassName("tabela")[0];
	var x=red.rows[index-1].innerHTML;
	red.rows[index-1].innerHTML=red.rows[index].innerHTML;
	red.rows[index].innerHTML=x;
}

function dislike(i) {
	var index=i.rowIndex;
	if (index==5) return false;
	var red = document.getElementsByClassName("tabela")[0];
	var x=red.rows[index+1].innerHTML;
	red.rows[index+1].innerHTML=red.rows[index].innerHTML;
	red.rows[index].innerHTML=x;
}

function likemob(i) {
	var index=i.rowIndex;
	if (index==0) return false;
	var red = document.getElementsByClassName("mobile-tabela")[0];
	var x0=red.rows[index].innerHTML,
		x1=red.rows[index+1].innerHTML,
		x2=red.rows[index+2].innerHTML,
		x3=red.rows[index+3].innerHTML,
		x4=red.rows[index+4].innerHTML;
		red.rows[index].innerHTML=red.rows[index-5].innerHTML;
		red.rows[index+1].innerHTML=red.rows[index-4].innerHTML;
		red.rows[index+2].innerHTML=red.rows[index-3].innerHTML;
		red.rows[index+3].innerHTML=red.rows[index-2].innerHTML;
		red.rows[index+4].innerHTML=red.rows[index-1].innerHTML;
		red.rows[index-5].innerHTML=x0;
		red.rows[index-4].innerHTML=x1;
		red.rows[index-3].innerHTML=x2;
		red.rows[index-2].innerHTML=x3;
		red.rows[index-1].innerHTML=x4;
}

function dislikemob(i) {
	var index=i.rowIndex;
	if (index==20) return false;
	var red = document.getElementsByClassName("mobile-tabela")[0];
	var x0=red.rows[index].innerHTML,
		x1=red.rows[index+1].innerHTML,
		x2=red.rows[index+2].innerHTML,
		x3=red.rows[index+3].innerHTML,
		x4=red.rows[index+4].innerHTML;
		red.rows[index].innerHTML=red.rows[index+5].innerHTML;
		red.rows[index+1].innerHTML=red.rows[index+6].innerHTML;
		red.rows[index+2].innerHTML=red.rows[index+7].innerHTML;
		red.rows[index+3].innerHTML=red.rows[index+8].innerHTML;
		red.rows[index+4].innerHTML=red.rows[index+9].innerHTML;
	red.rows[index+5].innerHTML=x0;
	red.rows[index+6].innerHTML=x1;
	red.rows[index+7].innerHTML=x2;
	red.rows[index+8].innerHTML=x3;
	red.rows[index+9].innerHTML=x4;
}