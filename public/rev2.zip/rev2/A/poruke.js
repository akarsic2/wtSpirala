/* Postoji var poruke lista koja ima element 0 ukoliko greska na istom indexu
 u porukeZaIspis odgovara formi studenta, a vrijednost 1 ako odgovara formi nastavnika
 da bi se vodila kontrola o tome koja ce se greska iduca ispisati */

var podnozje1=document.getElementById("podnozje1"); 
var podnozje2=document.getElementById("podnozje2"); 
var Poruke=(function(){
var idDivaPoruka;
var mogucePoruke=["Email koji ste napisali nije validan fakultetski email",
	"Indeks kojeg ste napisali nije validan",
	"Nastavna grupa koju ste napisali nije validna",
	"Akademska godina koju ste napisali nije validna",
	"Password mora sadržavati minimalno 7 karaktera od čega bar jedno veliko slovo, malo slovo i broj",
	"Passwordi se ne podudaraju",
	"Bitbucket URL nije validan",
	"Bitbucket SSH nije validan",
	"Naziv repozitorija nije validan",
	"Ime i prezime koje ste napisali nisu validni"]
var porukeZaIspis=[];
var porukeLista=[];
var ispisiGreske= function() {
	var div= document.getElementById(idDivaPoruka);
	if (porukeZaIspis.length===0) return;
	//Traži prvu gresku za formu student i ako postoji ispisuje je
	if (idDivaPoruka==="podnozje1") {
		var i= porukeLista.indexOf(0);
		if (i!==-1) div.innerHTML=porukeZaIspis[i];
	}
	//Traži prvu gresku za formu nastavnik i ako postoji ispisuje je
	else {
		var i=porukeLista.indexOf(1);
		if (i!==-1) div.innerHTML=porukeZaIspis[i];
	}
}
var postaviIdDiva = function(idDiva) {
	idDivaPoruka = idDiva;
}
var dodajPoruku = function(poruka) {
	porukeZaIspis.push(mogucePoruke[poruka]);
}
var ocistiGresku = function(poruka) {
	if (porukeZaIspis.includes(mogucePoruke[poruka])) {

		//Traze se dva indexa u slučaju da za obe forme ima ista greška
		var ind=porukeZaIspis.indexOf(mogucePoruke[poruka]);
		var ind2=porukeZaIspis.indexOf(mogucePoruke[poruka], ind+1);
		if (idDivaPoruka==="podnozje2") {
			if (ind2===-1) {
				porukeZaIspis.splice(ind,1);
				porukeLista.splice(ind,1);
			}
			else {
				//ako je u porukeLista vrijednost na indexu ind jednaka 1 
				//to znači da pripada formi za nastavnika
				if (porukeLista[ind]===1) {
					porukeZaIspis.splice(ind,1);
					porukeLista.splice(ind,1);
				}
				else {
					porukeZaIspis.splice(ind2,1);
					porukeLista.splice(ind2,1);
				}
			}
			//Trenutno prikazana greška je ona koja se briše
			var a=document.getElementById("podnozje2").innerHTML;
			if (a===mogucePoruke[poruka]) {
				document.getElementById("podnozje2").innerHTML="";
				if (porukeZaIspis.length!=0) {
					var i = porukeLista.indexOf(1);
					if (i!==-1) {
						document.getElementById("podnozje2").innerHTML=porukeZaIspis[i];
					}
				}
			}
		}
		else {
			if (ind2===-1) {
				porukeZaIspis.splice(ind,1);
				porukeLista.splice(ind,1);
			}
			else {
				if (porukeLista[ind]===0) {
					porukeZaIspis.splice(ind,1);
					porukeLista.splice(ind,1);
				}
				else {
					porukeZaIspis.splice(ind2,1);
					porukeLista.splice(ind2,1);
				}
			}
			var b= document.getElementById("podnozje1");
			if (b.innerHTML===mogucePoruke[poruka]) {
				document.getElementById("podnozje1").innerHTML="";
				if (porukeZaIspis.length!=0) {
					var i = porukeLista.indexOf(0);	
					if (i!==-1) {
						document.getElementById("podnozje1")=porukeZaIspis[i];
					}
				}
			}
		}
	}
}
return{
	porukeLista: porukeLista,
	ispisiGreske: ispisiGreske,
	postaviIdDiva: postaviIdDiva,
	dodajPoruku: dodajPoruku,
	ocistiGresku: ocistiGresku
	}
}());
