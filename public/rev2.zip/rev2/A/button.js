function postaviStudent() {
	document.getElementById("registerS").style.display="inline";
	document.getElementById("regN").style.display="none";
	document.getElementById("btnprofesor").style.background="white";
	document.getElementById("btnstudent").style.background="#4C2B48";
	document.getElementById("btnprofesor").style.color="black";
	document.getElementById("btnstudent").style.color="white";
	document.getElementById("podnozje1").style.display="inline";
	document.getElementById("podnozje2").style.display="none";			
}
function postaviNastavnik() {
	document.getElementById("regN").style.display="inline";
	document.getElementById("registerS").style.display="none";
	document.getElementById("btnprofesor1").style.background="#4C2B48";
	document.getElementById("btnstudent1").style.background="white";
	document.getElementById("btnprofesor1").style.color="white";
	document.getElementById("btnstudent1").style.color="black";
	document.getElementById("podnozje2").style.display="inline";
	document.getElementById("podnozje1").style.display="none";	
}
