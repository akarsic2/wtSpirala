var table = document.getElementById("tabelaSort");
var rows;
rows = table.getElementsByTagName("TR");

function moveUp(index){
	if(index.rowIndex > 1) {
		console.log(index.rowIndex);
		rows[index.rowIndex].parentNode.insertBefore(rows[index.rowIndex], rows[index.rowIndex - 1]);
	}
}

function moveDown(index) {
	if(index.rowIndex < rows.length - 1) {
		console.log(index.rowIndex);
		rows[index.rowIndex].parentNode.insertBefore(rows[index.rowIndex + 1], rows[index.rowIndex]);
	}
}