var Poruke = (function(){
	var idDivPoruka;
	var mogucePoruke = ["Email koji ste napisali nije validan fakultetski email",
						"Indeks kojeg ste napisali nije validan",
						"Nastavna grupa koju ste napisali nije validna",
						"Akademska godina koju ste napisali nije validna",
						"Password mora sadrzavati bar jedno veliko i malo slovo i bar jedan broj",
						"Passwordi se ne podudaraju",
						"Bitbucket URL nije validan",
						"Bitbucket SSH nije validan",
						"Naziv repozitorija nije validan",
						"Ime i Prezime treba da sadrzi 3 do 12 slova bosanske ili engleske abecede"];

	var porukeIspis = [];
	for(var i = 0; i < 10; i++) porukeIspis[i] = "";

	var ispisiGreske = function(){
		var div = document.getElementById(idDivPoruka);
		var ispis = "";
		for(var i = 0; i < porukeIspis.length; i++) {
			if(porukeIspis[i] != "")
			{
				ispis += porukeIspis[i] + "<br>"
			}
		}
		document.getElementById("ispisiPoruke").innerHTML = ispis;
	
	//	console.log(porukeIspis.length);
	}

	var postaviIdDiva = function(idDiva){
		idDivPoruka = idDiva;
	}

	var dodajPoruku = function(brojPoruke){
		if(brojPoruke >= 0 && brojPoruke < 10){
			for(var i = 0; i < 10; i++)
			{
				if(i == brojPoruke && porukeIspis[i] == "") {
					porukeIspis[i] = mogucePoruke[brojPoruke];
					break;
				}
			}
		}

	}

	var ocistiGresku = function(brojPoruke) {
		if(brojPoruke >= 0 && brojPoruke < 10) {
			for(var i = 0; i < 10; i++) {
				if(i == brojPoruke && porukeIspis[i] != "") {
					porukeIspis[i] = "";
					ispisiGreske();
					break;
				}
			}
		}

	}

	return {
		ispisiGreske : ispisiGreske,
		postaviIdDiva: postaviIdDiva,
		dodajPoruku : dodajPoruku,
		ocistiGresku : ocistiGresku
	}
}());