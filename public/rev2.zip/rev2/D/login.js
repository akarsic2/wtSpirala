function registrujNastavnika() {

    document.getElementById("poruke_r").innerHTML="";
    Poruke.postaviIdDivova("poruke_r");
    for(var i=0; i<10; ++i) Poruke.ocistiGresku(i);

    document.getElementsByClassName("forma-nastavnik")[0].style.display="block";
    document.getElementsByClassName("forma-student")[0].style.display="none";
}

function registrujStudenta() {

    document.getElementById("poruke_r").innerHTML="";
    Poruke.postaviIdDivova("poruke_r");
    for(var i=0; i<10; ++i) Poruke.ocistiGresku(i);

    document.getElementsByClassName("forma-nastavnik")[0].style.display="none";
    document.getElementsByClassName("forma-student")[0].style.display="block";
}