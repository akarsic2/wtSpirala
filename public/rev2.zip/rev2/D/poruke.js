var Poruke = (function(){

    var idDivaPoruke;
    var mogucePoruke=["Email koji ste napisali nije validan fakultetski email",
                    "Index koji ste napisali nije validan",
                    "Nastavna grupa koju ste napisali nije validna",
                    "Password koji ste unijeli nije validan",
                    "Passwordi se ne poklapaju",
                    "Akademska godina mora biti u formatu 20AB/20CD",
                    "BitBucket URL mora biti u formatu https://username@bitbucket.org/username2/nazivRepozitorija.git",
                    "BitBucket SSH mora biti u formatu git@bitbucket.org:username/nazivRepozitorija.git",
                    "Ime i Prezime koje ste napisali nije validno",
                    "Naziv repozitorija mora koji ste napisali nije validan"];

    var porukeZaIspis=[];

    return {

        ispisiGreske: function () {   /*ispisuje greske u div*/

            var ispis=[];
            for(var i=0; i<porukeZaIspis.length; ++i)
                ispis+="<p>"+porukeZaIspis[i]+"</p>";

            document.getElementById(idDivaPoruke).innerHTML=ispis.toString();
            document.getElementById(idDivaPoruke).style.background="#D8262E";
            document.getElementById(idDivaPoruke).style.border="#E4FDE1";
        },
        postaviIdDivova: function (id) {  /*postavlja id divova*/

            idDivaPoruke=id;
        },
        dodajPoruku: function (broj) {  /*dodaje poruku u niz poruka za ispis*/

            if(broj >= 0 && broj <mogucePoruke.length){
                var index=porukeZaIspis.indexOf(mogucePoruke[broj]);
                if(index < 0) porukeZaIspis.push(mogucePoruke[broj]);
            }
        },
        ocistiGresku: function (broj) {     /*brise iz niza gresku ako postoji*/

            if(broj >= 0 && broj < mogucePoruke.length){
                var index=porukeZaIspis.indexOf(mogucePoruke[broj]);
                if(index >= 0) porukeZaIspis.splice(index,1);
            }

            Poruke.ispisiGreske();
        }
    }
}());