function down(red) {
    
    var tabela = document.getElementById("tabelica");

    //prodjemo kroz sve redove tabele i ako jedan ima id kao traženi prekiramo
    //spasavamo u niz sve vrijednosti iz celija tabele
    for(var i = 1; i<tabela.rows.length -1; i++ ) {
        
        var tableChild = tabela.rows[i];
        if(tableChild.id == red) {
            var elementiCelije= [];
            for( var j = 0; j<tabela.rows[i].cells.length; j++) {
                elementiCelije.push(tabela.rows[i].cells[j].innerHTML);
            }
            break;
        }
    }
    
    //ako nije zadnji u pitanju brisemo red i ubacujemo novi
    if(i != tabela.rows.length-1) {
        tabela.deleteRow(i);
        var noviRed = tabela.insertRow(i+1);
        noviRed.id = red;
        for(var j = 0; j<elementiCelije.length; j++) {
            noviRed.insertCell(j).innerHTML = elementiCelije[j];
        }
         
    }
}

function up(red) {
    var tabela = document.getElementById("tabelica");

    
    for(var i = 1; i<tabela.rows.length; i++ ) {
        var tableChild = tabela.rows[i];
        
        if(tableChild.id == red) {
            var elementiCelije = [];
            for( var j = 0; j<tabela.rows[i].cells.length; j++) {
              elementiCelije.push(tabela.rows[i].cells[j].innerHTML);
            }
            break;
        }
    }
    
    if(i != 1) {
        tabela.deleteRow(i);
        var noviRed = tabela.insertRow(i-1);
        noviRed.id = red;
        for(var j = 0; j<elementiCelije.length; j++) {
            noviRed.insertCell(j).innerHTML =elementiCelije[j];
        }
         
    }
}