var Validacija=(function(){
var maxGrupa=7;
var trenutniSemestar=0;//0 za zimski, 1 za ljetni semestar
    
var validirajFakultetski = function(email) {
    if(email == null) return false;
    
    var regex = new RegExp(/^[a-zA-Z0-9.]+@etf.unsa.ba$/);
    var rezultat = regex.test(email);
			return rezultat;
}

var validirajIndex = function(indeks) {
       var brojIndeksa = indeks.toString();
    if (brojIndeksa.startsWith("1") && brojIndeksa.length === 5) {
        return true;
    }
    return false;
}
var validirajGrupu = function(broj) {
       if (broj < 1 || broj > maxGrupa) { return false; }
    return true;
}

var validirajAkGod = function(format) {
    
    if(format == null) { return false; }
    var currentTime = new Date();
    var year = currentTime.getFullYear().toString();
    
    var zimski = format.substring(0, 4);
    var ljetni = format.substring(5, 9);
    
    if ((parseInt(zimski) + 1) !== parseInt(ljetni)) { return false; }
    
    if ((trenutniSemestar === 0 && zimski !== year) || (trenutniSemestar === 1 && ljetni !== year)) { return false; }
    
    return true;
    
}

var validirajPassword = function(pass) {
    
    if(pass == null) { return false; }

    var regex = new RegExp(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{7,20}$/);
    var rezultat = regex.test(pass);
    return rezultat;
       
}

var validirajPotvrdu = function(string1, string2) {
    
    if(string1 == null || string2 == null) { return false; }

    if(validirajPassword(string1).toString() == "true" && validirajPassword(string2).toString() == "true") {
        return(string1 === string2);
    }
    else return false;
}


var validirajNazivRepozitorija = function(regeks, string) {
    
        
        if(regeks == null) {
        var reggy = new RegExp(/^wt[Pp]rojekat1[0-9]{4}$/);
        var rezzy = reggy.test(string);
        return rezzy;
  
        }
        else if(regeks != null) {
            var rezultat = regeks.test(string);
            return rezultat;
        }
}

var validirajBitbucketURL = function(url) {
    
    var regex = new RegExp(/^https:\/\/[a-zA-Z0-9.]+@bitbucket.org+\/[a-zA-Z0-9.]+[\/]{1}wt[Pp]rojekat+1[0-9]{4}.git$/);
    var rezultat = regex.test(url);
    return rezultat;
    
}


var validirajBitbucketSSH = function(string) {
    
    
    var regex = new RegExp(/^git@bitbucket.org:[a-zA-Z0-9]+[a-zA-Z0-9.]+\/wt[Pp]rojekat1[0-9]{4}.git$/);
    var rezultat = regex.test(string);
    return rezultat;
}


var validirajImeiPrezime = function(string) {
    
  var regex =  /^([A-ZŠĐŽĆČ]{1,1}[a-zA-Z-'ŠĐŽĆČšđžćč]{2,12})(( [A-ZŠĐŽĆČ]{1,1}[a-zA-Z-'ŠĐŽĆČšđžćč]{2,12})+)?$/
  var rezultat = regex.test(string);
    return rezultat;

}
var postaviMaxGrupa = function(broj) {
    
    maxGrupa = broj;
    return true;
}
var postaviTrenSemestar = function(semestar) {
    
    trenutniSemestar = semestar;
}
return{
validirajFakultetski:validirajFakultetski,
validirajIndex:validirajIndex,
validirajGrupu:validirajGrupu,
validirajAkGod:validirajAkGod,
validirajPassword:validirajPassword,
validirajPotvrdu:validirajPotvrdu,
validirajBitbucketURL:validirajBitbucketURL,
validirajBitbucketSSH:validirajBitbucketSSH,
validirajNazivRepozitorija:validirajNazivRepozitorija,
validirajImeiPrezime:validirajImeiPrezime,
postaviMaxGrupa:postaviMaxGrupa,
postaviTrenSemestar:postaviTrenSemestar
}
}());




