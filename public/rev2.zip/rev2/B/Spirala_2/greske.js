// funkcija koja brine o polju imeprezime i radi sa greškama
function validacijaImenaPrezimena(Validacija, Poruke, id) {
    
    var parametar = document.getElementById(id).value.toString();
    var provjera = Validacija.validirajImeiPrezime(parametar);
    Poruke.postaviIdDiva("greske");
    if(provjera.toString() == "false") {

        document.getElementById("imeprezime").style.border="2px solid red";
        Poruke.dodajPoruku(3);
        Poruke.ispisiGreske();
    }
    else if(provjera.toString() == "true"){
   
         document.getElementById("imeprezime").style.border="none";
         Poruke.ocistiGresku(3);
         Poruke.ispisiGreske();
       
    }
}

//funkcija koja brine u polju indeks ako je forma za studenta ili o polju korisnicko ime ako je nastavnik
function validacijaIndeksa(Validacija,Poruke,id) {
     Poruke.postaviIdDiva("greske");
    var staje = document.getElementById("labelaBrojIndeksa").innerHTML;
    
    if(staje == "Broj indeksa") {
    var parametar = document.getElementById(id).value.toString();
    var provjeraIndeksa = Validacija.validirajIndex(parseInt(parametar));
    
    if ( provjeraIndeksa.toString() == "false") {
       
        document.getElementById("indeks").style.border="2px solid red";
        Poruke.dodajPoruku(1);
        Poruke.ispisiGreske();
     
    }
    else if (provjeraIndeksa.toString() == "true") {
        
        document.getElementById("indeks").style.border="none";
        Poruke.ocistiGresku(1);
        Poruke.ispisiGreske();
        
    }
    }
    else if (staje == "Korisničko ime") {// za korisnicko ime nije specificirana validacija
        var parametar = document.getElementById(id).value.toString();
        
        if (parametar == "") {
       
        document.getElementById("indeks").style.border="2px solid red";
            Poruke.dodajPoruku(9);
            Poruke.ispisiGreske();
            }
        else if(parametar != "") {
            
            Poruke.ocistiGresku(9);
            Poruke.ispisiGreske();
      
            document.getElementById("indeks").style.border="none";
        }
       
    }
  }
    


//funkcija koja brine o polju broj grupe za studenta i password za nastavnika
function validacijaBrojaGrupe(Validacija,Poruke,id) {
    Poruke.postaviIdDiva("greske");
    var staje = document.getElementById("labelaBrojGrupe").innerHTML;
    
    if(staje == "Broj grupe") {
        var parametar = document.getElementById(id).value.toString();
        var provjeraBrojaGrupe = Validacija.validirajGrupu(parseInt(parametar));
        
        if(provjeraBrojaGrupe.toString() == "false" || parametar == "") {
            
        document.getElementById("brojGrupe").style.border="2px solid red";
            Poruke.dodajPoruku(2);
            Poruke.ispisiGreske();
        }
        
        else if(provjeraBrojaGrupe.toString() == "true") {
          
            document.getElementById("brojGrupe").style.border="none";
            Poruke.ocistiGresku(2);
            Poruke.ispisiGreske();
        }
        
                                                        
    }
    else if(staje == "Password") {
        
        var parametar = document.getElementById(id).value.toString();
        var provjeraPassworda = Validacija.validirajPassword(parametar);
        
        if(provjeraPassworda.toString() == "false") {
        
        document.getElementById("brojGrupe").style.border="2px solid red";
            Poruke.dodajPoruku(5);
            Poruke.ispisiGreske();
        }
        else if(provjeraPassworda.toString() == "true") {
                
           
             document.getElementById("brojGrupe").style.border="none";
            Poruke.ocistiGresku(5);
            Poruke.ispisiGreske();
        }
        
    }
    
}

//funkcija koja brine o polju za akademsku godini studenta i potvrdi passworda nastavnika
function validacijaAkademskeGodine(Validacija,Poruke,id) {
    Poruke.postaviIdDiva("greske");
    var staje = document.getElementById("labelaAkademskeGodine").innerHTML;
    
    if(staje == "Akademska godina")
        {
            var parametar = document.getElementById(id).value.toString();
            var provjeraAkademske = Validacija.validirajAkGod(parametar);
            
            if(provjeraAkademske.toString() == "false") {
            
            document.getElementById("akademskaGodina").style.border="2px solid red";
                Poruke.dodajPoruku(4);
                Poruke.ispisiGreske();
            
            }
            else if(provjeraAkademske.toString() == "true") {
                
               
                document.getElementById("akademskaGodina").style.border="none";
                Poruke.ocistiGresku(4);
                Poruke.ispisiGreske();
            }
        }
    else if(staje == "Potvrda passworda") {
        var string1 = document.getElementById(id).value.toString();
        var string2 = document.getElementById("brojGrupe").value.toString();
        
        var provjera = Validacija.validirajPotvrdu(string2, string1);
        if(provjera.toString() == "false") {
            
           
            document.getElementById("akademskaGodina").style.border="2px solid red";
            Poruke.dodajPoruku(6);
            Poruke.ispisiGreske();
        }
        else if(provjera.toString() == "true") {
            
              
            document.getElementById("akademskaGodina").style.border="none";
            Poruke.ocistiGresku(6);
            Poruke.ispisiGreske();
        }
        
    }
}

//funkcija koja brine o polju za password studenta i mail nastavnika
function validacijaPassworda(Validacija,Poruke, id) {
    Poruke.postaviIdDiva("greske");
    var staje = document.getElementById("labelapassword").innerHTML;
    if(staje == "Password") {
        
        var parametar = document.getElementById(id).value.toString();
        var provjeraPassworda = Validacija.validirajPassword(parametar);
        
        if(provjeraPassworda.toString() == "false") {
            
        document.getElementById("password").style.border="2px solid red";
            Poruke.dodajPoruku(5);
            Poruke.ispisiGreske();
        }
        else if(provjeraPassworda.toString() == "true") {
         
            document.getElementById("password").style.border="none";
            Poruke.ocistiGresku(5);
            Poruke.ispisiGreske();
        }
    }
    else if(staje == "Fakultetski mail") {
         var parametar = document.getElementById(id).value.toString();
         var provjeraMaila = Validacija.validirajFakultetski(parametar);
        
        if(provjeraMaila.toString() == "false") {
            
        
        document.getElementById("password").style.border="2px solid red";
            Poruke.dodajPoruku(0);
            Poruke.ispisiGreske();
        }
        else if(provjeraMaila.toString() == "true") {
            
            document.getElementById("password").style.border="none";
            Poruke.ocistiGresku(0);
            Poruke.ispisiGreske();
        }
        
    }
}

//funkcija koja brine o polju za potvrdu passworda za studenta i postavljanje maksimalnog broja grupa za nastavnike
function validacijaPotvrdePassworda(Validacija,Poruke, id) {
    var staje = document.getElementById("labelapasswordPotvrda").innerHTML;
    Poruke.postaviIdDiva("greske");
    if(staje == "Potvrda passworda") {
        
       var string1 = document.getElementById(id).value.toString();
       var string2 = document.getElementById("password").value.toString();
        
        var provjera = Validacija.validirajPotvrdu(string2, string1);
        if(provjera.toString() == "false") {
           
            document.getElementById("passwordPotvrda").style.border="2px solid red";
            
            Poruke.dodajPoruku(6);
            Poruke.ispisiGreske();
        }
        else if(provjera.toString() == "true") {
            
           
            document.getElementById("passwordPotvrda").style.border="none";
            Poruke.ocistiGresku(6);
            Poruke.ispisiGreske();
        }
    }
    
    else if(staje == "Maksimalni broj grupa") {
         var parametar = document.getElementById(id).value.toString();
         var provjera = Validacija.postaviMaxGrupa(parseInt(parametar));
        
        if(provjera.toString() == "false" || parametar == "") {
           
            document.getElementById("passwordPotvrda").style.border="2px solid red";
            
            Poruke.dodajPoruku(12);
            Poruke.ispisiGreske();
            
        }
        else if(parametar != "") {
           
            document.getElementById("passwordPotvrda").style.border="none";
            
            Poruke.ocistiGresku(12);
            Poruke.ispisiGreske();
        }
    }
    
}

//funkcija koja brine o polju za bitbucketurl studenta i regex za nastavnika
function validacijaBitBucketUrla(Validacija,Poruke,id) {
     var staje = document.getElementById("labelabitbucketURL").innerHTML;
    Poruke.postaviIdDiva("greske");
    if(staje == "BitBucket URL") {
        
        var parametar = document.getElementById(id).value.toString();
        var provjera = Validacija.validirajBitbucketURL(parametar);
        if(provjera.toString() == "false") {
            
            document.getElementById("bitbucketurl").style.border="2px solid red";
            Poruke.dodajPoruku(7);
            Poruke.ispisiGreske();
            
        }
        else if(provjera.toString() == "true") {
          
            document.getElementById("bitbucketurl").style.border="none";
            Poruke.ocistiGresku(12);
            Poruke.ispisiGreske();
        }
    }
   /* else if(staje == "Regex za validaciju") {
        
        var parametar = document.getElementById(id).value.toString();
        if(parametar)
        ovdje nema šta da se validira ??????????
    } */ 
    
}

//funkcija koja brine o polju bitbucketssh za studenta i odabiru semestra za nastavnika
function validacijaBitBucketSSH(Validacija,Poruke,id) {
    Poruke.postaviIdDiva("greske");
    var staje = document.getElementById("labelabitbucketSSH").innerHTML;
    if(staje == "BitBucket SSH") {
        var parametar = document.getElementById(id).value.toString();
        var provjera = Validacija.validirajBitbucketSSH(parametar);
        
        if(provjera.toString() == "false") {
            
            document.getElementById("bitbucketssh").style.border="2px solid red";
            Poruke.dodajPoruku(8);
            Poruke.ispisiGreske();
         
        }
        else if(provjera.toString() == "true") {
            

            document.getElementById("bitbucketssh").style.border="none";
            Poruke.ocistiGresku(8);
            Poruke.ocistiGresku();
        }
    }
    else if (staje == "Trenutni semestar") {
        
        var parametar = document.getElementById(id).value.toString();
        if(parametar == "" || parseInt(parametar) >1) {
            
           
            document.getElementById("bitbucketssh").style.border="2px solid red";
            Poruke.dodajPoruku(11);
            Poruke.ispisiGreske();
        }
        else if(parametar != "") {
              
            document.getElementById("bitbucketssh").style.border="none";
            Poruke.ocistiGresku(11);
            Poruke.ispisiGreske();
        }
    }
}

// funkcija koja brine o polju naziv repozitorij za studenta i o trenutnoj akademskoj za nastavnika
function validacijaNazivaRepozitorija(Validacija,Poruke,id) {
        Poruke.postaviIdDiva("greske");
       var staje = document.getElementById("labelaNazivRepozitorija").innerHTML;
    if(staje == "Naziv repozitorija") {
        
         var parametar = document.getElementById(id).value.toString();
        var provjera = Validacija.validirajNazivRepozitorija(null, parametar);
        
         if(provjera.toString() == "false") {
            
            document.getElementById("nazivrepozitorija").style.border="2px solid red";
             Poruke.dodajPoruku(10);
             Poruke.ispisiGreske();
        }
        else if(provjera.toString() == "true") {
      
            document.getElementById("nazivrepozitorija").style.border="none";
            Poruke.ocistiGresku(10);
            Poruke.ispisiGreske();
        }
        
    }
    else if(staje == "Trenutna akademska godina") {
        
            var parametar = document.getElementById(id).value.toString();
            var provjeraAkademske = Validacija.validirajAkGod(parametar);
            
            if(provjeraAkademske.toString() == "false") {
           
            document.getElementById("nazivrepozitorija").style.border="2px solid red";
            Poruke.dodajPoruku(4);
            Poruke.ispisiGreske();
            }
            else if(provjeraAkademske.toString() == "true") {
                
               
        document.getElementById("nazivrepozitorija").style.border="none";
                Poruke.ocistiGresku(4);
                Poruke.ispisiGreske();
            }
        
    }
}
