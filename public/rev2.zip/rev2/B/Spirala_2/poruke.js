var Poruke = (function(){
    
var idDivaPoruka;
var mogucePoruke = ["Email koji ste napisali nije validan fakultetski email",
                    "Broj indeksa koji ste napisali nije validan",
                    "Nastavna grupa koju ste napisali nije validna",
                    "Ime i prezime koje ste napisali nije validno",
                    "Akademska godina koju ste napisali nije validna",
                    "Password koji ste napisali nije validan",
                    "Password potvrda se ne podudara sa passwordom",
                    "BitBucket URL koji ste unijeli nije validan",
                    "BitBucket SSH koji ste unijeli nije validan",
                    "Username koji ste unijeli nije validan",
                    "Naziv repozitorija koji ste unijeli nije validan",
                    "Semestar koji ste unijeli nije validan",
                    "Broj nastavnih grupa koji ste unijeli nije validan"
                    ]

var porukeZaIspis=[];

var ispisiGreske = function() {
   var sadrzaj="";
    for(var i = 0; i < porukeZaIspis.length; i++) {
        sadrzaj += porukeZaIspis[i] + "<br>";
    }
    document.getElementById(idDivaPoruka).innerHTML = sadrzaj;
}
var postaviIdDiva = function(id) {
    idDivaPoruka = id;
}
var dodajPoruku = function(indeks) {
    var ima = porukeZaIspis.indexOf(mogucePoruke[indeks]);
    if(ima == -1) { porukeZaIspis.push(mogucePoruke[indeks]); }
    
}

var ocistiGresku = function(indeks) {
    if (indeks>=0 || indeks<=mogucePoruke.length -1) {
        
        var poruka = mogucePoruke[indeks];
        var indeksPoruke = porukeZaIspis.indexOf(poruka);
        porukeZaIspis.splice(indeksPoruke,1); }
 ///inačeeeeee greška...........
 
}
    
return{
ispisiGreske:ispisiGreske,
postaviIdDiva:postaviIdDiva,
dodajPoruku:dodajPoruku,
ocistiGresku:ocistiGresku
}
}());
