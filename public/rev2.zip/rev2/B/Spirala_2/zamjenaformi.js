function postaviNastavnicku(Poruke) {
    
    if(document.getElementById("dugme").value.toString() == "student") {
    
    document.getElementById("dugme").innerHTML ="Registracija studenta";
    document.getElementById("dugme").value = "nastavnik";
        
    if(document.getElementById("greske").innerHTML != "") {    
    Poruke.ocistiGresku(3);
    Poruke.ocistiGresku(1);
    Poruke.ocistiGresku(2);
    Poruke.ocistiGresku(4);
    Poruke.ocistiGresku(5);
    Poruke.ocistiGresku(6);
    Poruke.ocistiGresku(7);
    Poruke.ocistiGresku(10);
    Poruke.ocistiGresku(8);
     Poruke.ispisiGreske();
    }
    //reset ime prezime polja i svih greškica
    document.getElementById("imeprezime").value = "";
  


        //greske ime prezime

    document.getElementById("imeprezime").style.border="none";
        
        //greske indeks i korisnicko ime

    document.getElementById("indeks").style.border="none";
        
        //greske broj grupe i pass nastavnika
      
        document.getElementById("brojGrupe").style.border="none";
        
        //akademska godina i potvrda pass nastavnika
         
        document.getElementById("akademskaGodina").style.border="none";
        
        //password studenta i email
    
         document.getElementById("password").style.border="none";
        
        //potvrda pass studenta i maxbroj grupa
  
   document.getElementById("passwordPotvrda").style.border="none";
        
        //bitbucket url i regex
   
     document.getElementById("bitbucketurl").style.border="none";
        
        //bitbucket ssh i semestar
   
    document.getElementById("bitbucketssh").style.border="none";
        
        //naziv repozitorija
    document.getElementById("nazivrepozitorija").style.border="none";
            
        
    //broj indeksa->korisnicko ime
    document.getElementById("labelaBrojIndeksa").innerHTML = "Korisničko ime";
    document.getElementById("indeks").placeholder = "Username";
    document.getElementById("indeks").value = "";
    
    //broj grupe ->password
    document.getElementById("labelaBrojGrupe").innerHTML ="Password";
    document.getElementById("brojGrupe").type = "Password";
    document.getElementById("brojGrupe").placeholder = "*******";
    document.getElementById("brojGrupe").value = "";

    
    
    //akademska godina->potvrda passworda
    document.getElementById("labelaAkademskeGodine").innerHTML ="Potvrda passworda";
    document.getElementById("akademskaGodina").type ="Password";
    document.getElementById("akademskaGodina").placeholder = "*******";
    document.getElementById("akademskaGodina").value = "";

    
    //password ->mail
    document.getElementById("labelapassword").innerHTML ="Fakultetski mail";
    document.getElementById("password").type = "Text";
    document.getElementById("password").placeholder = "name@etf.unsa.ba";
    document.getElementById("password").value = "";

    
    //potvrda passworda -> maksimalni broj grupa
    document.getElementById("labelapasswordPotvrda").innerHTML = "Maksimalni broj grupa";
    document.getElementById("passwordPotvrda").type = "Number";
    document.getElementById("passwordPotvrda").placeholder = "X";
    document.getElementById("passwordPotvrda").max = "10";
    document.getElementById("passwordPotvrda").min = "1";
    document.getElementById("passwordPotvrda").value = "";
    
    
    //bitbucketurl ->regex 
    document.getElementById("labelabitbucketURL").innerHTML ="Regex za validaciju";
    document.getElementById("bitbucketurl").placeholder = "REGEX";
    document.getElementById("bitbucketurl").value = "";

    
    //bitbucketshh -> trenutni semestar
    document.getElementById("labelabitbucketSSH").innerHTML = "Trenutni semestar";
    document.getElementById("bitbucketssh").placeholder = "Zimski-0, Ljetni-1";
    document.getElementById("bitbucketssh").type = "Number";
    document.getElementById("bitbucketssh").max = "1";
    document.getElementById("bitbucketssh").min = "0";
    document.getElementById("bitbucketssh").value = "";
    
    //naziv repozitorija -> trenutna akademska
    document.getElementById("labelaNazivRepozitorija").innerHTML ="Trenutna akademska godina";
    document.getElementById("nazivrepozitorija").placeholder = "20AB/20CD";   
    document.getElementById("nazivrepozitorija").value = ""; 
    
}
    else if(document.getElementById("dugme").value.toString() == "nastavnik")
        {
            
     document.getElementById("dugme").innerHTML ="Registracija nastavnika";  
    document.getElementById("dugme").value = "student";
      document.getElementById("imeprezime").value = "";
    if(document.getElementById("greske").innerHTML != ""){
    Poruke.ocistiGresku(3);
    Poruke.ocistiGresku(9);
    Poruke.ocistiGresku(5);
    Poruke.ocistiGresku(6);
    Poruke.ocistiGresku(0);
    Poruke.ocistiGresku(11);
    Poruke.ocistiGresku(4);
     Poruke.ispisiGreske();
        //greske ime prezime
    }
    document.getElementById("imeprezime").style.border="none";
        
        //greske indeks i korisnicko ime

    document.getElementById("indeks").style.border="none";
        
        //greske broj grupe i pass nastavnika
      
        document.getElementById("brojGrupe").style.border="none";
        
        //akademska godina i potvrda pass nastavnika
         
        document.getElementById("akademskaGodina").style.border="none";
        
        //password studenta i email
    
         document.getElementById("password").style.border="none";
        
        //potvrda pass studenta i maxbroj grupa
  
     document.getElementById("passwordPotvrda").style.border="none";
        
        //bitbucket url i regex
   
     document.getElementById("bitbucketurl").style.border="none";
        
        //bitbucket ssh i semestar
   
     document.getElementById("bitbucketssh").style.border="none";
            
            //naziv repozitorija
        document.getElementById("nazivrepozitorija").style.border="none";
            
        
            
    //korisnicko ime -> broj indeksa
    document.getElementById("labelaBrojIndeksa").innerHTML = "Broj indeksa";
    document.getElementById("indeks").placeholder = "1xxxx";
    document.getElementById("indeks").value = "";

    
    //password -> broj grupe
     document.getElementById("labelaBrojGrupe").innerHTML ="Broj grupe";
    document.getElementById("brojGrupe").type = "Number";
    document.getElementById("brojGrupe").placeholder = "X";
    document.getElementById("brojGrupe").value = "";
    document.getElementById("brojGrupe").min = "1";
    
    //potvrda passworda ->akademska godina
    document.getElementById("labelaAkademskeGodine").innerHTML ="Akademska godina";
     document.getElementById("akademskaGodina").type ="Text";
    document.getElementById("akademskaGodina").placeholder = "20AB/20CD";
    document.getElementById("akademskaGodina").value = "";
    
    //mail -> password
    document.getElementById("labelapassword").innerHTML ="Password";
    document.getElementById("password").type = "Password";
    document.getElementById("password").placeholder = "********";
    document.getElementById("password").value = "";
    
    //maksimalni broj grupa->potvrda passworda
      document.getElementById("labelapasswordPotvrda").innerHTML = "Potvrda passworda";
    document.getElementById("passwordPotvrda").type = "Password";
    document.getElementById("passwordPotvrda").placeholder = "********";
    document.getElementById("passwordPotvrda").value = "";
    
    //regex ->bitbucketurl
    document.getElementById("labelabitbucketURL").innerHTML ="BitBucket URL";
    document.getElementById("bitbucketurl").placeholder = "bitbucketURL";
    document.getElementById("bitbucketurl").value = "";
    
    //trenutni semestar ->bitbucketssh
    document.getElementById("labelabitbucketSSH").innerHTML = "BitBucket SSH";
    document.getElementById("bitbucketssh").placeholder = "bitbucketSSH";
    document.getElementById("bitbucketssh").type = "text";
    document.getElementById("bitbucketssh").value = "";
    
    //trenutna akademska -> naziv repozitorija
    
    document.getElementById("labelaNazivRepozitorija").innerHTML ="Naziv repozitorija";
    document.getElementById("nazivrepozitorija").placeholder = "nazivRepozitorija"; 
    document.getElementById("nazivrepozitorija").value = "";  
            
        }
}
